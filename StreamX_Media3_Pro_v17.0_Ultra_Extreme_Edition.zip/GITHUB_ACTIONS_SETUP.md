# GitHub Actions setup — v17.0

Upload the extracted project contents to the root of a GitHub repository. Go to **Actions**, enable workflows if prompted, select **StreamX Media3 Pro v17.0 Ultra Extreme - Single Release APK**, and choose **Run workflow**. The workflow runs source verification, unit tests, and a Release APK build. Download the APK from the completed run's **Artifacts** section.

For repeatable update installs over an existing app, configure the same persistent Android signing keystore in repository Actions secrets: `ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS`, and `ANDROID_KEY_PASSWORD`. Without these secrets, the workflow uses the debug key for test installation; that key may not match a previously installed release.
