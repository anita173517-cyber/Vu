package com.harindra.iptvpro

import android.util.JsonReader
import android.util.JsonToken
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.Request
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import kotlin.coroutines.coroutineContext

/**
 * StreamX Media3 Pro v17.0 Ultra Extreme Edition — Xtream Codes High-Speed Repository.
 *
 * - Safe request cancellation & in-flight deduplication mutex.
 * - Automatic transient error retry with bounded exponential backoff.
 * - Category string interning and zero-DOM streaming JsonReader for 60,000+ entries on 512MB RAM TVs.
 * - Dual-Stream Automatic Failover: pairs primary .m3u8 live URLs with .ts MPEG-TS backup URLs.
 * - Full support for Live TV and VOD Movies, with bounded transient-error retry and cancellation.
 * - Consistent alternate MPEG-TS URL selection for duplicate live-channel entries.
 */
class XtreamRepository {
    private val fetchMutex = Mutex()

    @Volatile
    private var activeCall: Call? = null

    companion object {
        private const val DEFAULT_MAX_STREAMS = 60_000
        private const val FIRST_BATCH_SIZE = 80
        private const val XTREAM_CALL_TAG = "xtream_api_call"
    }

    fun cancelActiveFetch() {
        runCatching { activeCall?.cancel() }
        activeCall = null
        NetworkClient.cancelCallsWithTag(XTREAM_CALL_TAG)
    }

    fun normalizeServerBaseUrl(rawServerUrl: String): String {
        val cleaned = ProfileStore.sanitizeExternalInput(rawServerUrl).removeSuffix("/")
        if (cleaned.isEmpty()) throw IllegalArgumentException("Server URL is empty")
        return if (cleaned.startsWith("http://", true) || cleaned.startsWith("https://", true)) {
            cleaned
        } else {
            "http://$cleaned"
        }
    }

    private fun apiUrl(base: String, creds: XtreamCredentials, action: String): String {
        val normalizedBase = normalizeServerBaseUrl(base)
        val parsed = normalizedBase.toHttpUrlOrNull() ?: throw IllegalArgumentException("Invalid Xtream server URL")
        return parsed.newBuilder()
            .addPathSegment("player_api.php")
            .addQueryParameter("username", creds.username.trim())
            .addQueryParameter("password", creds.password.trim())
            .addQueryParameter("action", action)
            .build()
            .toString()
    }

    private fun readStringSafe(reader: JsonReader, default: String = ""): String {
        return when (reader.peek()) {
            JsonToken.NULL -> {
                reader.nextNull()
                default
            }
            JsonToken.STRING, JsonToken.NUMBER -> reader.nextString()
            JsonToken.BOOLEAN -> reader.nextBoolean().toString()
            else -> {
                reader.skipValue()
                default
            }
        }
    }

    private fun readIntSafe(reader: JsonReader, default: Int): Int {
        return when (reader.peek()) {
            JsonToken.NULL -> {
                reader.nextNull()
                default
            }
            JsonToken.NUMBER -> runCatching { reader.nextInt() }.getOrElse {
                runCatching { reader.nextString().toIntOrNull() ?: default }.getOrDefault(default)
            }
            JsonToken.STRING -> reader.nextString().toIntOrNull() ?: default
            else -> {
                reader.skipValue()
                default
            }
        }
    }

    private suspend fun fetchCategoriesMap(cleanBase: String, creds: XtreamCredentials, action: String, fallbackLabel: String): Map<String, String> {
        val categoriesMap = HashMap<String, String>(128)
        val catUrl = apiUrl(cleanBase, creds, action)
        try {
            val req = Request.Builder()
                .url(catUrl)
                .tag(XTREAM_CALL_TAG)
                .header("User-Agent", NetworkClient.DEFAULT_USER_AGENT)
                .build()
            val call = NetworkClient.fastMetaClient.newCall(req)
            activeCall = call
            call.execute().use { res ->
                val body = res.body
                if (res.isSuccessful && body != null) {
                    JsonReader(BufferedReader(InputStreamReader(body.byteStream(), Charsets.UTF_8), 16384)).use { reader ->
                        if (reader.peek() == JsonToken.BEGIN_ARRAY) {
                            reader.beginArray()
                            while (reader.hasNext()) {
                                coroutineContext.ensureActive()
                                if (reader.peek() != JsonToken.BEGIN_OBJECT) {
                                    reader.skipValue()
                                    continue
                                }
                                var catId = ""
                                var catName = fallbackLabel
                                reader.beginObject()
                                while (reader.hasNext()) {
                                    when (reader.nextName()) {
                                        "category_id" -> catId = readStringSafe(reader).trim()
                                        "category_name" -> catName = readStringSafe(reader, fallbackLabel).trim().ifBlank { fallbackLabel }
                                        else -> reader.skipValue()
                                    }
                                }
                                reader.endObject()
                                if (catId.isNotEmpty()) {
                                    categoriesMap[catId] = catName.intern()
                                }
                            }
                            reader.endArray()
                        }
                    }
                }
            }
        } catch (e: Exception) {
            coroutineContext.ensureActive()
            Log.w("StreamX", "Category fetch note ($action): ${e.message}")
        }
        return categoriesMap
    }

    private fun describeHttpFailure(code: Int): String = when (code) {
        401, 403 -> "Invalid Xtream username/password or expired account (HTTP $code)"
        404 -> "Xtream player_api.php endpoint not found on server (HTTP 404)"
        429 -> "Server rate limit reached (HTTP 429) — wait a moment and retry"
        in 500..599 -> "Xtream server temporary overload (HTTP $code)"
        else -> "Server returned HTTP $code"
    }

    suspend fun fetchLiveStreams(
        creds: XtreamCredentials,
        maxStreams: Int = DEFAULT_MAX_STREAMS,
        onFirstBatchReady: (suspend (List<Channel>) -> Unit)? = null
    ): Result<List<Channel>> = withContext(Dispatchers.IO) {
        fetchMutex.withLock {
            var lastError: Exception? = null
            for (attempt in 1..2) {
                coroutineContext.ensureActive()
                try {
                    val cleanBase = normalizeServerBaseUrl(creds.serverUrl)
                    val categoriesMap = fetchCategoriesMap(cleanBase, creds, "get_live_categories", "Live TV")
                    val streamsUrl = apiUrl(cleanBase, creds, "get_live_streams")
                    val req = Request.Builder()
                        .url(streamsUrl)
                        .tag(XTREAM_CALL_TAG)
                        .header("User-Agent", NetworkClient.DEFAULT_USER_AGENT)
                        .build()
                    val call = NetworkClient.apiClient.newCall(req)
                    activeCall = call

                    call.execute().use { res ->
                        if (!res.isSuccessful) {
                            val msg = describeHttpFailure(res.code)
                            if (res.code in 500..599 && attempt == 1) {
                                lastError = IOException(msg)
                            } else {
                                return@withLock Result.failure(Exception(msg))
                            }
                        } else {
                            val body = res.body ?: return@withLock Result.failure(Exception("Empty server response"))
                            val list = ArrayList<Channel>(4096)
                            val seenIds = HashSet<String>(4096)
                            val primaryIndexByNormHash = HashMap<Long, Int>(4096)
                            val cleanUser = creds.username.trim()
                            val cleanPass = creds.password.trim()
                            val streamPrefix = "$cleanBase/live/$cleanUser/$cleanPass/"
                            var firstBatchDispatched = false

                            JsonReader(BufferedReader(InputStreamReader(body.byteStream(), Charsets.UTF_8), 65536)).use { reader ->
                                if (reader.peek() != JsonToken.BEGIN_ARRAY) {
                                    return@withLock Result.failure(Exception("Invalid Xtream credentials or non-list server response"))
                                }
                                reader.beginArray()
                                var index = 0
                                while (reader.hasNext() && list.size < maxStreams) {
                                    if (index % 1000 == 0) coroutineContext.ensureActive()
                                    if (reader.peek() != JsonToken.BEGIN_OBJECT) {
                                        reader.skipValue()
                                        continue
                                    }
                                    index++
                                    var streamId = ""
                                    var num = index
                                    var name = ""
                                    var catId = ""
                                    var icon = ""
                                    var epgChannelId = ""

                                    reader.beginObject()
                                    while (reader.hasNext()) {
                                        when (reader.nextName()) {
                                            "stream_id" -> streamId = readStringSafe(reader).trim()
                                            "num" -> num = readIntSafe(reader, index)
                                            "name" -> name = readStringSafe(reader).trim()
                                            "category_id" -> catId = readStringSafe(reader).trim()
                                            "stream_icon" -> icon = readStringSafe(reader).trim()
                                            "epg_channel_id" -> epgChannelId = readStringSafe(reader).trim()
                                            else -> reader.skipValue()
                                        }
                                    }
                                    reader.endObject()

                                    if (streamId.isNotEmpty() && seenIds.add(streamId)) {
                                        val resolvedCategory = categoriesMap[catId] ?: "Live TV"
                                        val resolvedName = name.ifBlank { "Channel ${list.size + 1}" }
                                        val candidateUrl = "$streamPrefix$streamId.m3u8"
                                        val tsFallbackUrl = "$streamPrefix$streamId.ts"
                                        val normHash = M3uParser.fnv1a64NormalizedPair(resolvedCategory, resolvedName)
                                        val existingIdx = primaryIndexByNormHash[normHash]
                                        if (existingIdx != null && existingIdx in list.indices) {
                                            val primary = list[existingIdx]
                                            // Keep the documented dual-format policy: primary HLS (.m3u8)
                                            // with an alternate stream ID in MPEG-TS (.ts) form.
                                            // Do not accidentally replace the TS fallback with another HLS URL.
                                            if (primary.backupUrl.isBlank() || primary.backupUrl.endsWith(".ts", ignoreCase = true)) {
                                                list[existingIdx] = primary.copy(backupUrl = tsFallbackUrl)
                                            }
                                        } else {
                                            val resolvedNum = if (num > 0) num else list.size + 1
                                            val newIdx = list.size
                                            list.add(
                                                Channel(
                                                    id = streamId,
                                                    number = resolvedNum,
                                                    name = resolvedName,
                                                    category = resolvedCategory,
                                                    streamUrl = candidateUrl,
                                                    logoUrl = icon,
                                                    epgId = epgChannelId,
                                                    backupUrl = tsFallbackUrl
                                                )
                                            )
                                            primaryIndexByNormHash.putIfAbsent(normHash, newIdx)
                                            if (!firstBatchDispatched && list.size == FIRST_BATCH_SIZE && onFirstBatchReady != null) {
                                                firstBatchDispatched = true
                                                onFirstBatchReady.invoke(ArrayList(list))
                                            }
                                        }
                                    }
                                }
                                while (reader.hasNext()) {
                                    reader.skipValue()
                                }
                                reader.endArray()
                            }
                            activeCall = null
                            return@withLock Result.success(list)
                        }
                    }
                } catch (e: Exception) {
                    coroutineContext.ensureActive()
                    lastError = e
                    Log.w("StreamX", "Xtream fetchLiveStreams attempt $attempt warning: ${e.message}")
                    if (attempt == 1) {
                        delay(650L)
                    }
                } finally {
                    activeCall = null
                }
            }
            Result.failure(lastError ?: Exception("Failed to load Xtream channels"))
        }
    }

    /**
     * Fetches VOD Movies from the Xtream Codes server (`get_vod_categories` + `get_vod_streams`)
     * using the same ultra-low-memory streaming JsonReader architecture.
     */
    suspend fun fetchVodStreams(
        creds: XtreamCredentials,
        maxStreams: Int = 20_000,
        startingNumber: Int = 10_001
    ): Result<List<Channel>> = withContext(Dispatchers.IO) {
        fetchMutex.withLock {
            var lastError: Exception? = null
            for (attempt in 1..2) {
                coroutineContext.ensureActive()
                try {
                    val cleanBase = normalizeServerBaseUrl(creds.serverUrl)
                    val categoriesMap = fetchCategoriesMap(cleanBase, creds, "get_vod_categories", "Movies")
                    val vodUrl = apiUrl(cleanBase, creds, "get_vod_streams")
                    val req = Request.Builder()
                        .url(vodUrl)
                        .tag(XTREAM_CALL_TAG)
                        .header("User-Agent", NetworkClient.DEFAULT_USER_AGENT)
                        .build()
                    val call = NetworkClient.apiClient.newCall(req)
                    activeCall = call
                    call.execute().use { res ->
                        if (!res.isSuccessful) {
                            val message = describeHttpFailure(res.code)
                            if ((res.code == 429 || res.code in 500..599) && attempt == 1) {
                                lastError = IOException(message)
                            } else {
                                return@withLock Result.failure(Exception(message))
                            }
                        } else {
                            val body = res.body ?: return@withLock Result.failure(Exception("Empty VOD response"))
                            val list = ArrayList<Channel>(2048)
                            val cleanUser = creds.username.trim()
                            val cleanPass = creds.password.trim()
                            val moviePrefix = "$cleanBase/movie/$cleanUser/$cleanPass/"

                            JsonReader(BufferedReader(InputStreamReader(body.byteStream(), Charsets.UTF_8), 65536)).use { reader ->
                                if (reader.peek() != JsonToken.BEGIN_ARRAY) {
                                    return@withLock Result.success(emptyList())
                                }
                                reader.beginArray()
                                var index = 0
                                while (reader.hasNext() && list.size < maxStreams) {
                                    if (index % 1000 == 0) coroutineContext.ensureActive()
                                    if (reader.peek() != JsonToken.BEGIN_OBJECT) {
                                        reader.skipValue()
                                        continue
                                    }
                                    index++
                                    var streamId = ""
                                    var name = ""
                                    var catId = ""
                                    var icon = ""
                                    var ext = "mp4"

                                    reader.beginObject()
                                    while (reader.hasNext()) {
                                        when (reader.nextName()) {
                                            "stream_id" -> streamId = readStringSafe(reader).trim()
                                            "name" -> name = readStringSafe(reader).trim()
                                            "category_id" -> catId = readStringSafe(reader).trim()
                                            "stream_icon" -> icon = readStringSafe(reader).trim()
                                            "container_extension" -> ext = readStringSafe(reader, "mp4").trim().ifBlank { "mp4" }
                                            else -> reader.skipValue()
                                        }
                                    }
                                    reader.endObject()

                                    if (streamId.isNotEmpty()) {
                                        val safeExtension = ext.removePrefix(".").take(12).filter { it.isLetterOrDigit() }.ifBlank { "mp4" }
                                        val rawCat = categoriesMap[catId] ?: "Movies"
                                        val vodCat = if (rawCat.startsWith("🎬")) rawCat else "🎬 $rawCat"
                                        list.add(
                                            Channel(
                                                id = "vod_$streamId",
                                                number = startingNumber + list.size,
                                                name = name.ifBlank { "Movie ${list.size + 1}" },
                                                category = vodCat,
                                                streamUrl = "$moviePrefix$streamId.$safeExtension",
                                                logoUrl = icon
                                            )
                                        )
                                    }
                                }
                                while (reader.hasNext()) reader.skipValue()
                                reader.endArray()
                            }
                            return@withLock Result.success(list)
                        }
                    }
                } catch (e: Exception) {
                    coroutineContext.ensureActive()
                    lastError = e
                    Log.w("StreamX", "Xtream fetchVodStreams attempt $attempt warning: ${e.message}")
                    if (e is IllegalArgumentException) return@withLock Result.failure(e)
                } finally {
                    activeCall = null
                }
                if (attempt == 1) delay(650L)
            }
            Result.failure(lastError ?: Exception("Failed to load Xtream VOD movies"))
        }
    }

}
