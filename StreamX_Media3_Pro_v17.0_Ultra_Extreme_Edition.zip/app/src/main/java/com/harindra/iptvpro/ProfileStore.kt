package com.harindra.iptvpro

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Locale
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

enum class ProfileType { M3U, XTREAM }

data class PlaylistProfile(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val type: ProfileType,
    val source: String,
    val username: String = "",
    val password: String = ""
)

class ProfileStore(context: Context) {
    private val appContext = context.applicationContext
    private val fastMetaPrefs: SharedPreferences =
        appContext.getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)

    @Volatile
    private var usingFallbackPrefs: Boolean = false

    // Lazy initialization: Tink/KeyStore is NEVER loaded on cold boot if the user has no saved profiles
    private val securePrefs: SharedPreferences by lazy {
        try {
            usingFallbackPrefs = false
            EncryptedSharedPreferences.create(
                appContext,
                "streamx_secure_profiles",
                MasterKey.Builder(appContext).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            usingFallbackPrefs = true
            Log.w("StreamX", "EncryptedSharedPreferences unavailable on this TV; using AES-GCM protected fallback")
            appContext.getSharedPreferences("streamx_profiles_fallback", Context.MODE_PRIVATE)
        }
    }

    @Volatile
    private var cachedProfiles: MutableList<PlaylistProfile>? = null

    companion object {
        private const val PIN_HASH_KEY = "parental_pin_hash_v2"
        private const val PIN_SALT_KEY = "parental_pin_salt_v2"
        private const val LEGACY_PIN_KEY = "parental_pin_code"
        private const val FALLBACK_ENC_PREFIX = "ENC1:"

        fun sanitizeExternalInput(raw: String): String {
            if (raw.isEmpty()) return ""
            return raw
                .replace("\u200B", "")
                .replace("\uFEFF", "")
                .trim()
        }

        fun computeSaltedPinHash(pin: String, saltHex: String): String {
            val md = MessageDigest.getInstance("SHA-256")
            var digest = "$saltHex:${pin.trim()}".toByteArray(Charsets.UTF_8)
            repeat(1000) {
                md.reset()
                md.update(digest)
                digest = md.digest()
            }
            return digest.joinToString("") { "%02x".format(it) }
        }

        fun verifySaltedPinHash(candidatePin: String, saltHex: String, expectedHashHex: String): Boolean {
            if (candidatePin.length != 4 || expectedHashHex.isBlank() || saltHex.isBlank()) return false
            val actualHashHex = computeSaltedPinHash(candidatePin, saltHex)
            return MessageDigest.isEqual(
                actualHashHex.toByteArray(Charsets.UTF_8),
                expectedHashHex.toByteArray(Charsets.UTF_8)
            )
        }
    }

    private fun getOrCreateFallbackAesKey(): SecretKeySpec {
        var seedHex = fastMetaPrefs.getString("fallback_kdf_seed", null)
        if (seedHex.isNullOrBlank()) {
            val randomBytes = ByteArray(32)
            SecureRandom().nextBytes(randomBytes)
            seedHex = randomBytes.joinToString("") { "%02x".format(it) }
            fastMetaPrefs.edit().putString("fallback_kdf_seed", seedHex).apply()
        }
        val keyBytes = MessageDigest.getInstance("SHA-256")
            .digest(("StreamX_AES256_${appContext.packageName}_$seedHex").toByteArray(Charsets.UTF_8))
        return SecretKeySpec(keyBytes, "AES")
    }

    private fun encryptFallbackPayload(plainJson: String): String {
        return try {
            val iv = ByteArray(12)
            SecureRandom().nextBytes(iv)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateFallbackAesKey(), GCMParameterSpec(128, iv))
            val cipherBytes = cipher.doFinal(plainJson.toByteArray(Charsets.UTF_8))
            val combined = ByteArray(iv.size + cipherBytes.size)
            System.arraycopy(iv, 0, combined, 0, iv.size)
            System.arraycopy(cipherBytes, 0, combined, iv.size, cipherBytes.size)
            FALLBACK_ENC_PREFIX + Base64.encodeToString(combined, Base64.NO_WRAP)
        } catch (_: Exception) {
            plainJson
        }
    }

    private fun decryptFallbackPayload(stored: String): String {
        if (!stored.startsWith(FALLBACK_ENC_PREFIX)) {
            // Backward-compatible read for any pre-existing unprefixed JSON array
            return stored
        }
        return try {
            val raw = Base64.decode(stored.removePrefix(FALLBACK_ENC_PREFIX), Base64.NO_WRAP)
            if (raw.size <= 12) return "[]"
            val iv = raw.copyOfRange(0, 12)
            val cipherBytes = raw.copyOfRange(12, raw.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateFallbackAesKey(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(cipherBytes), Charsets.UTF_8)
        } catch (e: Exception) {
            Log.w("StreamX", "Fallback profile decrypt warning: ${e.message}")
            "[]"
        }
    }

    @Synchronized
    fun all(): MutableList<PlaylistProfile> {
        cachedProfiles?.let { return it.toMutableList() }
        // Fast-path skip of Tink KeyStore on cold boot if no profile has ever been saved
        if (!fastMetaPrefs.getBoolean("has_saved_profiles", true)) {
            val empty = mutableListOf<PlaylistProfile>()
            cachedProfiles = empty
            return mutableListOf()
        }
        val rawStored = try {
            securePrefs.getString("profiles", "[]") ?: "[]"
        } catch (e: Exception) {
            Log.w("StreamX", "Failed to read saved profiles")
            "[]"
        }
        val raw = if (rawStored.startsWith(FALLBACK_ENC_PREFIX)) {
            decryptFallbackPayload(rawStored)
        } else {
            rawStored
        }
        val parsed = try {
            val arr = JSONArray(raw)
            MutableList(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                PlaylistProfile(
                    id = sanitizeExternalInput(o.optString("id")).ifBlank { UUID.randomUUID().toString() },
                    name = sanitizeExternalInput(o.optString("name", "IPTV Account")).ifBlank { "IPTV Account" },
                    type = runCatching { ProfileType.valueOf(o.optString("type", "M3U")) }.getOrDefault(ProfileType.M3U),
                    source = sanitizeExternalInput(o.optString("source")),
                    username = sanitizeExternalInput(o.optString("username")),
                    password = sanitizeExternalInput(o.optString("password"))
                )
            }
        } catch (e: Exception) {
            Log.w("StreamX", "Corrupted profile JSON; resetting in-memory list")
            mutableListOf()
        }
        cachedProfiles = parsed
        fastMetaPrefs.edit().putBoolean("has_saved_profiles", parsed.isNotEmpty()).apply()
        return parsed.toMutableList()
    }

    @Synchronized
    fun save(profile: PlaylistProfile) {
        val cleanProfile = profile.copy(
            name = sanitizeExternalInput(profile.name).ifBlank { "IPTV Account" },
            source = sanitizeExternalInput(profile.source),
            username = sanitizeExternalInput(profile.username),
            password = sanitizeExternalInput(profile.password)
        )
        val list = all()
        val idx = list.indexOfFirst { it.id == cleanProfile.id }
        if (idx >= 0) list[idx] = cleanProfile else list.add(cleanProfile)
        persist(list)
    }

    @Synchronized
    fun delete(id: String) = persist(all().filterNot { it.id == id })

    fun activeId(): String? = try {
        fastMetaPrefs.getString("active_profile_id_fast", null)
            ?: if (fastMetaPrefs.getBoolean("has_saved_profiles", false)) securePrefs.getString("active_id", null) else null
    } catch (e: Exception) {
        Log.w("StreamX", "Failed to read active profile ID")
        null
    }

    fun setActive(id: String) {
        try {
            fastMetaPrefs.edit().putString("active_profile_id_fast", id).apply()
            if (fastMetaPrefs.getBoolean("has_saved_profiles", false)) {
                securePrefs.edit().putString("active_id", id).apply()
            }
        } catch (e: Exception) {
            Log.w("StreamX", "Failed to save active profile ID")
        }
    }

    // Salted SHA-256 4-Digit Parental PIN Lock with Legacy Compatibility
    fun hasParentalPin(): Boolean {
        val hash = fastMetaPrefs.getString(PIN_HASH_KEY, "") ?: ""
        if (hash.isNotBlank()) return true
        val legacy = fastMetaPrefs.getString(LEGACY_PIN_KEY, "") ?: ""
        return legacy.length == 4
    }

    fun getParentalPin(): String {
        return if (hasParentalPin()) "****" else ""
    }

    fun verifyParentalPin(candidatePin: String): Boolean {
        val trimmed = candidatePin.trim()
        if (trimmed.length != 4) return false
        val savedHash = fastMetaPrefs.getString(PIN_HASH_KEY, "") ?: ""
        val savedSalt = fastMetaPrefs.getString(PIN_SALT_KEY, "") ?: ""
        if (savedHash.isNotBlank() && savedSalt.isNotBlank()) {
            return verifySaltedPinHash(trimmed, savedSalt, savedHash)
        }
        val legacyPin = fastMetaPrefs.getString(LEGACY_PIN_KEY, "") ?: ""
        if (legacyPin.length == 4 && legacyPin == trimmed) {
            // Transparently upgrade verified legacy PIN to salted SHA-256 hash without locking user out
            setParentalPin(trimmed)
            return true
        }
        return false
    }

    fun setParentalPin(pin: String) {
        val clean = pin.trim()
        if (clean.isEmpty()) {
            fastMetaPrefs.edit()
                .remove(PIN_HASH_KEY)
                .remove(PIN_SALT_KEY)
                .remove(LEGACY_PIN_KEY)
                .apply()
            return
        }
        val saltBytes = ByteArray(16)
        SecureRandom().nextBytes(saltBytes)
        val saltHex = saltBytes.joinToString("") { "%02x".format(it) }
        val hashHex = computeSaltedPinHash(clean, saltHex)
        fastMetaPrefs.edit()
            .putString(PIN_SALT_KEY, saltHex)
            .putString(PIN_HASH_KEY, hashHex)
            .remove(LEGACY_PIN_KEY)
            .apply()
    }

    fun getLockedCategories(): Set<String> {
        return fastMetaPrefs.getStringSet("locked_categories", emptySet())?.toSet() ?: emptySet()
    }

    fun toggleCategoryLock(category: String): Boolean {
        val norm = category.trim()
        val current = getLockedCategories().toMutableSet()
        val nowLocked = if (current.contains(norm)) {
            current.remove(norm)
            false
        } else {
            current.add(norm)
            true
        }
        fastMetaPrefs.edit().putStringSet("locked_categories", current).apply()
        return nowLocked
    }

    fun isCategoryLocked(category: String): Boolean {
        if (!hasParentalPin()) return false
        val norm = category.trim()
        if (getLockedCategories().any { it.equals(norm, ignoreCase = true) }) return true
        val lower = norm.lowercase(Locale.ROOT)
        return lower.contains("adult") || lower.contains("18+") || lower.contains("xxx")
    }

    fun getPreferredAudioLanguage(channelId: String): String? {
        return fastMetaPrefs.getString("audio_lang_$channelId", null)?.takeIf { it.isNotBlank() }
    }

    fun setPreferredAudioLanguage(channelId: String, language: String) {
        fastMetaPrefs.edit().putString("audio_lang_$channelId", language.trim()).apply()
    }

    @Synchronized
    private fun persist(list: List<PlaylistProfile>) {
        cachedProfiles = list.toMutableList()
        fastMetaPrefs.edit().putBoolean("has_saved_profiles", list.isNotEmpty()).apply()
        try {
            val arr = JSONArray()
            list.forEach { p ->
                arr.put(
                    JSONObject()
                        .put("id", p.id)
                        .put("name", p.name)
                        .put("type", p.type.name)
                        .put("source", p.source)
                        .put("username", p.username)
                        .put("password", p.password)
                )
            }
            val rawJson = arr.toString()
            val prefInstance = securePrefs
            val toStore = if (usingFallbackPrefs) encryptFallbackPayload(rawJson) else rawJson
            prefInstance.edit().putString("profiles", toStore).apply()
        } catch (e: Exception) {
            Log.w("StreamX", "Failed to persist profiles")
        }
    }
}
