# StreamX Media3 Pro — v17.0 Ultra Extreme Edition

This is the v17.0 source project, based on the supplied v16.0 Ultra Max Edition. It preserves the existing app identity/package, 4D Glass TV interface, Android TV remote controls, Media3 playback/preload pipeline, M3U/Xtream/XMLTV EPG flows, SXB2 channel cache, encrypted profile/PIN storage, and low-memory protections.

## v17.0 changes

- Fixed duplicate Xtream live-channel pairing so the selected alternate URL remains an MPEG-TS `.ts` fallback rather than being overwritten with a second HLS `.m3u8` URL.
- Added bounded two-attempt recovery for transient Xtream VOD HTTP/network failures, with coroutine cancellation checks and active-call cancellation support.
- Serialized Xtream VOD loading through the same repository mutex as live loading to avoid overlapping large JSON parses on low-memory devices.
- Sanitized Xtream VOD container extensions before constructing movie stream URLs.
- Updated app version metadata to `17.0` / version code `170` and updated the GitHub Actions APK artifact name.
- Added v17-specific structural checks for the Xtream fallback/retry changes.

## Preserved platform baseline

- Minimum Android: 6.0 (API 23)
- Target SDK: 34; Compile SDK: 36
- Java/Kotlin target: 17
- Gradle: 8.13; Android Gradle Plugin: 8.13.2 (project plugin management)
- Media3: 1.11.1
- No `largeHeap`; optional extension renderers remain disabled for the low-RAM profile.
- HLS preload memory remains bounded by the existing implementation; no unbounded speculative preloading was added.

## Build on GitHub (free Actions minutes subject to GitHub account limits)

1. Create a GitHub repository and upload the **contents** of this ZIP to the repository root (not the ZIP nested inside another ZIP).
2. Open **Actions** and enable workflows if GitHub asks.
3. Select **StreamX Media3 Pro v17.0 Ultra Extreme - Single Release APK**.
4. Press **Run workflow**. A push to `main` or `master` also starts the workflow.
5. Wait for the green completed run. Open the run, scroll to **Artifacts**, and download `StreamX-Media3-Pro-v17.0-Ultra-Extreme-Edition-512MB.apk`.

The workflow runs the offline structural verifier, unit tests, and `assembleRelease`, then validates the APK archive before uploading it. Without signing secrets it uses the Gradle debug signing key; this is installable for testing but is not a persistent production signing identity. For upgrade installs over an older release, use the same signing key as the installed build.

## Important test status

The included source-level verifier can be run with `python3 scripts/verify_project.py`. The actual Android Gradle build is delegated to GitHub Actions because this source-authoring environment does not include the Android SDK/Gradle build toolchain. Physical playback, channel-zap timing, IPTV provider compatibility, and 512MB TV stability still require testing on the target television and network. No numeric speed-up is claimed without those measurements.
